import torch
import torch.nn as nn
import torch.nn.functional as F

class GDB(nn.Module):
    def __init__(self, gradient_strength=0.5):
        super().__init__()
        self.gradient_strength = gradient_strength
        self.sobel_x = nn.Conv2d(1,1,3,padding=1,bias=False)
        self.sobel_y = nn.Conv2d(1,1,3,padding=1,bias=False)
        sobel_x_weight = torch.tensor(
            [[-1, 0, 1],
             [-2, 0, 2],
             [-1, 0, 1]], dtype=torch.float32
        ).view(1, 1, 3, 3)
        sobel_y_weight = torch.tensor(
            [[-1, -2, -1],
             [ 0,  0,  0],
             [ 1,  2,  1]], dtype=torch.float32
        ).view(1, 1, 3, 3)
        self.sobel_x.weight.data = sobel_x_weight
        self.sobel_y.weight.data = sobel_y_weight
        for param in self.sobel_x.parameters(): param.requires_grad=False
        for param in self.sobel_y.parameters(): param.requires_grad=False

    def forward(self, x, x_mean):
        gx = self.sobel_x(x_mean)
        gy = self.sobel_y(x_mean)
        grad = torch.sqrt(gx ** 2 + gy ** 2 + 1e-8)

        g_min, _ = torch.min(grad.view(grad.size(0), grad.size(1), -1), dim=2, keepdim=True)
        g_max, _ = torch.max(grad.view(grad.size(0), grad.size(1), -1), dim=2, keepdim=True)
        g_min = g_min.view(grad.size(0), grad.size(1), 1, 1)
        g_max = g_max.view(grad.size(0), grad.size(1), 1, 1)
        grad = (grad - g_min) / (g_max - g_min + 1e-8)
        grad = grad * self.gradient_strength + (1.0 - 0.5 * self.gradient_strength)

        return x * grad


class PPDB(nn.Module):
    def __init__(self, periodic_strength=0.3):
        super().__init__()
        self.periodic_strength = periodic_strength
        self.periodic_conv = nn.Conv2d(1, 3, kernel_size=3, padding=1, bias=False)
        kernels = torch.stack([
            torch.tensor([[0, 1, 0],
                          [1,-4, 1],
                          [0, 1, 0]], dtype=torch.float32),
            torch.tensor([[-1,-1,-1],
                          [-1, 8,-1],
                          [-1,-1,-1]], dtype=torch.float32),
            torch.tensor([[1, 0,-1],
                          [0, 0, 0],
                          [-1, 0, 1]], dtype=torch.float32)
        ], dim=0).view(3, 1, 3, 3)
        self.periodic_conv.weight.data = kernels
        for param in self.periodic_conv.parameters():
            param.requires_grad = False

        self.periodic_attention = nn.Sequential(
            nn.Conv2d(3, 1, 1, bias=False),
            nn.Sigmoid()
        )
    def forward(self, x, x_mean):
        feat = self.periodic_conv(x_mean)
        attn = self.periodic_attention(feat)
        attn = attn * self.periodic_strength + (1.0 - 0.5 * self.periodic_strength)

        return x * attn


class SimamModule(torch.nn.Module):
    def __init__(self, e_lambda=1e-4):
        super(SimamModule, self).__init__()
        self.act = nn.Sigmoid()
        self.e_lambda = e_lambda

    def forward(self, x):
        _, _, h, w = x.size()
        n = w * h - 1
        x_minus_mu_square = (x - x.mean(dim=[2, 3], keepdim=True)).pow(2)
        y = x_minus_mu_square / (4 * (x_minus_mu_square.sum(dim=[2, 3], keepdim=True) / n + self.e_lambda)) + 0.5
        return x * self.act(y)

class XBSAM(nn.Module):
    def __init__(self, ksize=3, stride=1, rate=2, fuse_k=3, softmax_scale=10.0, gradient_strength=0.5, periodic_strength=0.3,):
        super().__init__()
        self.ksize = ksize
        self.stride = stride
        self.rate = rate
        self.softmax_scale = softmax_scale
        self.fuse_k = fuse_k
        self.gradient_strength = gradient_strength
        self.periodic_strength = periodic_strength
        self.gdb = GDB(gradient_strength)
        self.ppdb = PPDB(periodic_strength) 
        self.simam = SimamModule(e_lambda=1e-4)
        self.register_buffer('fuse_weight', torch.eye(fuse_k).view(1, 1, fuse_k, fuse_k).float())
        
        self.padding = (self.ksize-1)//2

    def extract_patches(self, x, kernel_size, stride, padding, rate=1):
        return F.unfold(x, kernel_size=kernel_size, dilation=rate,padding=padding, stride=stride*rate)

    def forward(self, attn_feat, mask):
        B, C, H, W = attn_feat.size()
        x_mean = attn_feat.mean(dim=1, keepdim=True)
        attn_feat = self.gdb(attn_feat, x_mean)
        attn_feat = self.ppdb(attn_feat, x_mean)
        attn_feat = self.simam(attn_feat)
    
        f_down = F.interpolate(attn_feat, scale_factor=1/self.rate, mode='nearest')
        w = self.extract_patches(f_down, self.ksize, self.stride, self.padding)
        w = w.view(B, C, self.ksize, self.ksize, -1).permute(0,4,1,2,3) 
        raw_w = w

        mask_down = F.interpolate(mask.float(), scale_factor=1/self.rate, mode='nearest')
        m = self.extract_patches(mask_down, self.ksize, self.stride, self.padding)
        m = m.view(B, 1, -1)
        yi = (m.mean(dim=2, keepdim=True) == 0).float()
        
        H_down, W_down = H // self.rate, W // self.rate
        
        Y = []
        for i in range(B):
            Xi = f_down[i:i+1]
            wi = w[i]
            xi = wi / torch.sqrt((wi**2).sum(dim=(1,2,3), keepdim=True)).clamp(min=1e-4)
            
            Yi = F.conv2d(Xi, xi, padding=self.ksize//2, groups=1)
            
            current_yi = yi[i].view(1, 1, 1, 1)
            Yi = Yi * current_yi
            Yi = F.softmax(Yi * self.softmax_scale, dim=1)
            
            weight = raw_w[i].permute(0, 1, 2, 3).contiguous()
            Yi = F.conv_transpose2d(Yi, weight, stride=self.rate, padding=self.rate//2) / 4.0
            Yi = F.interpolate(Yi, size=(H, W), mode='nearest')
            
            Y.append(Yi)
        
        return torch.cat(Y, dim=0)


