import torch
import torch.nn as nn
import torch.nn.functional as F

class Attn(nn.Module):
    def __init__(self, in_channels, window_size=11, pad_mode='overlap'):
        super().__init__()
        self.window_size = window_size
        self.conv_query = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.conv_key = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.conv_value = nn.Conv2d(in_channels, in_channels, 1)
        self.conv_out = nn.Conv2d(in_channels, in_channels, 1)
        self.softmax = nn.Softmax(dim=-1)
        assert pad_mode in ('overlap', 'pad_to_divisible', 'no_pad')
        self.pad_mode = pad_mode

    def forward(self, F_en, F_de):
        B, C, H_orig, W_orig = F_en.shape
        win = self.window_size

        Q = self.conv_query(F_de)   
        K = self.conv_key(F_en)     
        V = self.conv_value(F_en)  

        if self.pad_mode == 'no_pad':
            stride = win
            pad_h = pad_w = 0
        elif self.pad_mode == 'pad_to_divisible':
            pad_h = (win - (H_orig % win)) % win
            pad_w = (win - (W_orig % win)) % win
            if pad_h != 0 or pad_w != 0:
                pad = (0, pad_w, 0, pad_h)  
                Q = F.pad(Q, pad, mode='reflect')
                K = F.pad(K, pad, mode='reflect')
                V = F.pad(V, pad, mode='reflect')
            stride = win
        else: 
            stride = max(1, win // 2)
            H2 = ((H_orig - win) // stride + 1) * stride + win
            W2 = ((W_orig - win) // stride + 1) * stride + win
            pad_h = max(0, H2 - H_orig)
            pad_w = max(0, W2 - W_orig)
            if pad_h != 0 or pad_w != 0:
                pad = (0, pad_w, 0, pad_h)
                Q = F.pad(Q, pad, mode='reflect')
                K = F.pad(K, pad, mode='reflect')
                V = F.pad(V, pad, mode='reflect')

        _, Cq, H2, W2 = Q.shape
        S = win * win

        Q_unf = F.unfold(Q, kernel_size=win, stride=stride) 
        K_unf = F.unfold(K, kernel_size=win, stride=stride)
        V_unf = F.unfold(V, kernel_size=win, stride=stride)

        N = Q_unf.shape[-1]

        Q_unf = Q_unf.view(B, Cq, S, N).permute(0, 3, 1, 2).contiguous()
        K_unf = K_unf.view(B, Cq, S, N).permute(0, 3, 1, 2).contiguous()
        V_unf = V_unf.view(B, C, S, N).permute(0, 3, 1, 2).contiguous()

        attn = torch.einsum('bncs,bnct->bnst', Q_unf, K_unf) 
        attn = attn / (Cq ** 0.5)
        attn = self.softmax(attn)  

        out = torch.einsum('bnst,bnct->bncs', attn, V_unf)

        out = out.permute(0, 2, 3, 1).contiguous().view(B, C * S, N)

        out_fold = F.fold(out, output_size=(H2, W2), kernel_size=win, stride=stride)

        if stride != win:
            ones = torch.ones(B, C, H2, W2, device=out_fold.device, dtype=out_fold.dtype)
            ones_unf = F.unfold(ones, kernel_size=win, stride=stride)
            norm = F.fold(ones_unf, output_size=(H2, W2), kernel_size=win, stride=stride)
            out_fold = out_fold / (norm + 1e-6)

        if H2 != H_orig or W2 != W_orig:
            out_fold = out_fold[:, :, :H_orig, :W_orig]

        return self.conv_out(out_fold)
    

class FCR(nn.Module):
    def __init__(self, in_channels, window_size=11, C1=0.8, C2=0.8):
        super().__init__()
        self.o_struct = Attn(in_channels, window_size)
        self.channel_adjust = nn.Conv2d(in_channels, in_channels, 1)

        self.gate_conv = nn.Conv2d(in_channels * 2, 1, 1)
        self.sigmoid = nn.Sigmoid()
        self.C1 = C1
        self.C2 = C2

    def forward(self, F_en, F_de):
        o_struct = self.o_struct(F_en, F_de)

        gate_input = torch.cat([F_en, o_struct], dim=1)
        gate_weight = self.sigmoid(self.gate_conv(gate_input))

        gate_weight = self.C1 + self.C2 * gate_weight

        output = (1 - gate_weight) * F_en + gate_weight * o_struct
        return self.channel_adjust(output)


