import torch
import torch.nn as nn
import torch.nn.functional as F


class SCAM(nn.Module):
    def __init__(self, in_channels, top_k=32, kernel_size=3, temperature=0.25):
        super(SCAM, self).__init__()
        self.in_channels = in_channels
        self.top_k = top_k             
        self.kernel_size = kernel_size
        self.temperature = temperature

    def extract_patches_stridek(self, x):
        ks = self.kernel_size
        _, _, H, W = x.size()

        pad_h = (ks - H % ks) % ks
        pad_w = (ks - W % ks) % ks
        pad_top = pad_h // 2
        pad_bottom = pad_h - pad_top
        pad_left = pad_w // 2
        pad_right = pad_w - pad_left

        x = F.pad(x, (pad_left, pad_right, pad_top, pad_bottom), mode='reflect')
        _, _, Hp, Wp = x.size()

        patches = F.unfold(x, kernel_size=ks, stride=ks)  
        patches = patches.view(1, self.in_channels, ks, ks, -1)

        return patches[0], Hp, Wp

    def csa_function(self, input, mask):
        _, C, H, W = input.size()
        ks = self.kernel_size
        center = ks // 2

        patches, Hp, Wp = self.extract_patches_stridek(input)

        L = patches.size(-1)
        Hs = Hp // ks
        Ws = Wp // ks

        rows = torch.arange(Hs, device=mask.device).repeat_interleave(Ws)
        cols = torch.arange(Ws, device=mask.device).repeat(Hs)
        cy = rows * ks + center
        cx = cols * ks + center
        patch_mask = mask[cy, cx]       
        gap_mask = (patch_mask == 1)
        nongap_mask = (patch_mask == 0)

        gap_patches = patches[..., gap_mask]        
        nongap_patches = patches[..., nongap_mask]  

        D = C * ks * ks
        gap_flat = gap_patches.reshape(D, -1)       
        nongap_flat = nongap_patches.reshape(D, -1) 

        gap_norm = F.normalize(gap_flat, dim=0)
        nongap_norm = F.normalize(nongap_flat, dim=0)
        sim = torch.matmul(nongap_norm.t(), gap_norm)

        K = min(self.top_k, sim.size(0))
        topk_sim, topk_idx = torch.topk(sim, k=K, dim=0)
        weights = F.softmax(topk_sim / self.temperature, dim=0)

        sel = nongap_flat[:, topk_idx]

        fused = torch.sum(sel * weights.unsqueeze(0), dim=1)

        fused = fused.view(C, ks, ks, -1)  
  
        output_patches = patches.clone()
        output_patches[..., gap_mask] = fused

        output = F.fold(
            output_patches.view(1, C * ks * ks, -1),
            output_size=(Hp, Wp),
            kernel_size=ks,
            stride=ks
        )

        output = output[:, :, :H, :W]

        return output


    def forward(self, x, mask):
        outputs = []
        for i in range(x.size(0)):
            out_i = self.csa_function(x[i:i+1], mask[i, 0])
            outputs.append(out_i)
        return torch.cat(outputs, dim=0)
