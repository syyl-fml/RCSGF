import os
import imageio.v2 as imageio
import numpy as np
import random
import cv2
from tqdm import tqdm
from collections import defaultdict

IMAGE_SIZE = 512
BUFFER_DISTANCE = 30  
TARGET_RATIO = (0.65, 0.70) 

GRID_TYPES = [
    (1, 1)  
]

def generate_gap_mask_2d(image):
    H, W = image.shape
    gap_mask = np.zeros_like(image, dtype=bool)
    for i in range(25, H - 25):
        if np.all((image[i, :] > 60000) | (image[i, :] <= 0)):
            gap_mask[i, :] = True
    for j in range(25, W - 25):
        if np.all((image[:, j] > 60000) | (image[:, j] <= 0)):
            gap_mask[:, j] = True
    return gap_mask

def get_gap_surrounding_mask(gap_mask):
    kernel = np.ones((2*BUFFER_DISTANCE+1, 2*BUFFER_DISTANCE+1), np.uint8)
    dilated_gap = cv2.dilate(gap_mask.astype(np.uint8), kernel)
    return (dilated_gap - gap_mask.astype(np.uint8)) > 0

def is_position_valid(occupied, region_mask, y, x, h, w):
    if y + h > region_mask.shape[0] or x + w > region_mask.shape[1]:
        return False
    if not np.all(region_mask[y:y+h, x:x+w]):
        return False
    if np.any(occupied[y:y+h, x:x+w]):
        return False
        
    y_start = max(0, y-1)
    x_start = max(0, x-1)
    y_end = min(occupied.shape[0], y+h+1)
    x_end = min(occupied.shape[1], x+w+1)
    
    extended_area = occupied[y_start:y_end, x_start:x_end]
    mask = np.ones_like(extended_area, dtype=bool)
    if extended_area.shape[0] > 2 and extended_area.shape[1] > 2:
        mask[0, 0] = False
        mask[0, -1] = False
        mask[-1, 0] = False
        mask[-1, -1] = False
    
    if np.any(extended_area & mask):
        return False
    return True

def mark_occupied(occupied, y, x, h, w):
    occupied[y:y+h, x:x+w] = True

def generate_mixed_grid_mask(region_mask, gap_mask, target_ratio):
    H, W = region_mask.shape
    
    occupied = np.zeros_like(region_mask, dtype=bool)
    final_mask = np.zeros_like(region_mask, dtype=np.uint8)

    h_bounds, v_bounds = [], []
    i = 0
    while i < H:
        if np.all(gap_mask[i, :]):
            start = i
            while i < H and np.all(gap_mask[i, :]): i += 1
            h_bounds.append((start, i))
        else:
            i += 1

    j = 0
    while j < W:
        if np.all(gap_mask[:, j]):
            start = j
            while j < W and np.all(gap_mask[:, j]): j += 1
            v_bounds.append((start, j))
        else:
            j += 1
            
    def add_fixed_gap(y1, y2, x1, x2):
        y1, y2 = max(0, int(y1)), min(H, int(y2))
        x1, x2 = max(0, int(x1)), min(W, int(x2))
        if y1 < y2 and x1 < x2:
            final_mask[y1:y2, x1:x2] = 1
            occupied[y1:y2, x1:x2] = True

    if len(h_bounds) > 0 and len(v_bounds) > 0:
        for idx, (h_s, h_e) in enumerate(h_bounds):
            for (v_s, v_e) in v_bounds:
                up_len = 89 if idx == 0 else 72
                down_len = 89 if idx == len(h_bounds) - 1 else 72
                
                add_fixed_gap(h_s - 20, h_s - 10, 0, v_s - 10)
                add_fixed_gap(h_s - 10 - up_len, h_s - 10, v_s - 20, v_s - 10)
                
                add_fixed_gap(h_e + 10, h_e + 20, 0, v_s - 10)
                add_fixed_gap(h_e + 10, h_e + 10 + down_len, v_s - 20, v_s - 10)
                
                add_fixed_gap(h_s - 20, h_s - 10, v_e + 10, W)
                add_fixed_gap(h_s - 10 - up_len, h_s - 10, v_e + 10, v_e + 20)
                
                add_fixed_gap(h_e + 10, h_e + 20, v_e + 10, W)
                add_fixed_gap(h_e + 10, h_e + 10 + down_len, v_e + 10, v_e + 20)

    available_for_dots = np.logical_and(region_mask, ~occupied)
    target_pixels = int(np.sum(available_for_dots) * random.uniform(*target_ratio))
    
    y_coords, x_coords = np.where(available_for_dots)
    valid_indices = np.arange(len(y_coords))
    np.random.shuffle(valid_indices) 
    
    pixels_placed = 0
    placed_grids = defaultdict(int) 
    
    for idx in valid_indices:
        if pixels_placed >= target_pixels:
            break
            
        y, x = y_coords[idx], x_coords[idx]
        if occupied[y, x]:
            continue
        
        shuffled_grid_types = list(GRID_TYPES)
        random.shuffle(shuffled_grid_types)
            
        placed = False
        for grid_size in shuffled_grid_types:
            h, w = grid_size
            if not is_position_valid(occupied, region_mask, y, x, h, w):
                continue
                
            final_mask[y:y+h, x:x+w] = 1
            mark_occupied(occupied, y, x, h, w)
            pixels_placed += h * w
            placed_grids[(h, w)] += 1
            placed = True
            break
        
        if not placed:
            if is_position_valid(occupied, region_mask, y, x, 1, 1):
                final_mask[y, x] = 1
                occupied[y, x] = True
                pixels_placed += 1
                placed_grids[(1, 1)] += 1
    
    if pixels_placed < target_pixels:
        available = np.logical_and(region_mask, ~occupied)
        y_coords_avail, x_coords_avail = np.where(available)
        num_needed = int(target_pixels - pixels_placed)
        
        if num_needed > 0 and len(y_coords_avail) > 0:
            actual_add = min(num_needed, len(y_coords_avail))
            indices = np.random.choice(len(y_coords_avail), actual_add, replace=False)
            for i in indices:
                y, x = y_coords_avail[i], x_coords_avail[i]
                final_mask[y, x] = 1
                occupied[y, x] = True
                pixels_placed += 1
                placed_grids[(1, 1)] += 1
    
    total_available_area = np.sum(available_for_dots)
    actual_ratio = pixels_placed / total_available_area if total_available_area > 0 else 0
    target_ratio_val = target_pixels / total_available_area if total_available_area > 0 else 0
    print(f"混合方格掩码比例: {actual_ratio:.1%} (目标: {target_ratio_val:.1%})")
    
    return final_mask

def process_image_mixed_grids(image_path, output_path):
    original = imageio.imread(image_path)
    if original.dtype != np.uint16:
        original = original.astype(np.uint16)
    
    gap_mask = generate_gap_mask_2d(original)
    
    surrounding_mask = get_gap_surrounding_mask(gap_mask)
    
    grid_mask = generate_mixed_grid_mask(surrounding_mask, gap_mask, TARGET_RATIO)
    
    masked = original.copy()
    masked[surrounding_mask] = original[surrounding_mask] * (1 - grid_mask[surrounding_mask])
    
    imageio.imwrite(output_path, masked)

input_dir = r''
output_dir = r''

if __name__ == '__main__':
    os.makedirs(output_dir, exist_ok=True)

    files = [f for f in os.listdir(input_dir) if f.lower().endswith('.tif')]
    for filename in tqdm(files, desc="生成固定L型平移掩码"):
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, filename)
        process_image_mixed_grids(input_path, output_path)

    print("固定平移掩码生成完成！")