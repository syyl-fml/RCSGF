import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
import warnings

def create_protected_region_mask(batch_size):
    IMAGE_SIZE = 512
    mask = torch.ones((batch_size, 1, IMAGE_SIZE, IMAGE_SIZE), dtype=torch.float32)  
    
    y_top_img = IMAGE_SIZE - 1 - 511
    y_bottom_img = IMAGE_SIZE - 1 - 383
    x_left_img = IMAGE_SIZE - 1 - 192
    x_right_img = IMAGE_SIZE - 1 - 129
    x_start, x_end = sorted([x_left_img, x_right_img])
    y_start, y_end = sorted([y_top_img, y_bottom_img])
    
    x_start = max(x_start, 0)
    x_end = min(x_end, IMAGE_SIZE - 1)
    y_start = max(y_start, 0)
    y_end = min(y_end, IMAGE_SIZE - 1)
    mask[:, :, y_start:y_end+1, x_start:x_end+1] = 0
    return mask


def generate_gap_mask_batch(images, batch_size):
    batch_size, _, H, W = images.shape
    device = images.device 
    gap_mask_batch = torch.zeros((batch_size, 1, H, W), dtype=torch.bool, device=device)

    valid_samples = torch.ones(batch_size, dtype=torch.bool, device=device)

    for i in range(batch_size):
        image_2d = images[i, 0, :, :]
        gap_mask = torch.zeros_like(image_2d, dtype=torch.bool, device=device)

        consecutive_rows = 0
        max_gap_rows = 0
        for row in range(25, H - 25):
            if torch.all((image_2d[row, :] > 60000) | (image_2d[row, :] <= 0)):
                gap_mask[row, :] = True
                consecutive_rows += 1
                max_gap_rows = max(max_gap_rows, consecutive_rows)
            else:
                consecutive_rows = 0

        consecutive_cols = 0
        max_gap_cols = 0
        for col in range(25, W - 25):
            if torch.all((image_2d[:, col] > 60000) | (image_2d[:, col] <= 0)):
                gap_mask[:, col] = True
                consecutive_cols += 1
                max_gap_cols = max(max_gap_cols, consecutive_cols)
            else:
                consecutive_cols = 0

        gap_mask_batch[i, 0, :, :] = gap_mask

        if (max_gap_rows > min(H * 0.1, 50) or
            max_gap_cols > min(W * 0.1, 50)):
            valid_samples[i] = False
            warnings.warn(
                "Detected gap width exceeds the intended application range "
                f"(rows={max_gap_rows}, cols={max_gap_cols}). "
                "This image will be skipped."
            )
    return gap_mask_batch, valid_samples

def generate_gap_mask_2d(image):
    H, W = image.shape  
    matrix_values = image
    gap_mask = np.zeros_like(matrix_values, dtype=bool)
    gap_rows = []  
    gap_cols = [] 

    for i in range(25, H - 25):
        if np.all((matrix_values[i, :] > 60000) | (matrix_values[i, :] <= 0)):
            gap_mask[i, :] = True
            gap_rows.append(i)
    for j in range(25, W - 25):
        if np.all((matrix_values[:, j] > 60000) | (matrix_values[:, j] <= 0)):
            gap_mask[:, j] = True  
            gap_cols.append(j) 
    return  gap_mask


def generate_gap_arbitrary_mask_batch(images, GTs):
    irregular_mask = (GTs != 0) & (images == 0)
    return irregular_mask

def generate_gap_arbitrary_mask_2d(image, GT):
    irregular_mask = (GT != 0) & (image == 0)
    return irregular_mask

class MSELoss(nn.Module):
    def __init__(self):
        super(MSELoss, self).__init__()
    def forward(self, output_stage1, output_stage2, GT_full_batch, masks, gap):
        return F.mse_loss(output_stage2, GT_full_batch)

class NonGapMSELoss(nn.Module):
    def __init__(self):
        super(NonGapMSELoss, self).__init__()
        
    def forward(self, output_stage1, output_stage2, GT_full_batch, masks, gap):
        with torch.no_grad():
            nongap_mask = (gap == 0).float() 
            num_nongap = nongap_mask.sum() + 1e-8

        diff = (output_stage2 - GT_full_batch) ** 2
        nongap_diff = diff * nongap_mask

        return nongap_diff.sum() / num_nongap

class NonGapPSNR(nn.Module):
    def __init__(self):
        super(NonGapPSNR, self).__init__()
        
    def forward(self, output_stage1, output_stage2, GT_full_batch, masks, gap):
        with torch.no_grad():
            nongap_mask = (gap == 0).float() 
            num_nongap = nongap_mask.sum() + 1e-8

        mse = ((output_stage2 - GT_full_batch) ** 2 * nongap_mask).sum() / num_nongap
        
        psnr = -10.0 * torch.log10(mse + 1e-8)
        
class SGALoss(nn.Module):
    def __init__(self, 
                 blank_threshold=1e-8,
                 stage1_weight=0.5,
                 stage2_weight=0.5,
                 gap_weight=0.95,
                 global_weight=0.05):
        super(SGALoss, self).__init__()
        self.blank_threshold = blank_threshold
        self.stage1_weight = stage1_weight
        self.stage2_weight = stage2_weight
        self.gap_weight = gap_weight
        self.global_weight = global_weight

    def forward(self, output_stage1, output_stage2, GT_full_batch, masks, gap):
        with torch.no_grad():
            mask = (masks > 0).float()
            gap = (gap == 0).float()

            num_gap = mask.sum() + 1e-8
            num_nongap = gap.sum() + 1e-8

        def compute_gap_loss(output):
            diff = (output - GT_full_batch) ** 2
            gap_diff = diff * mask
            return gap_diff.sum() / num_gap

        def compute_global_loss(output):
            diff = (output - GT_full_batch) ** 2
            gap_diff = diff * gap
            return gap_diff.sum() / num_nongap

        def compute_stage_loss(output):
            gap_l = compute_gap_loss(output)
            global_l = compute_global_loss(output)
            return self.gap_weight * gap_l + self.global_weight * global_l

        loss_stage1 = self.stage1_weight * compute_stage_loss(output_stage1)
        loss_stage2 = self.stage2_weight * compute_stage_loss(output_stage2)

        return loss_stage1 + loss_stage2